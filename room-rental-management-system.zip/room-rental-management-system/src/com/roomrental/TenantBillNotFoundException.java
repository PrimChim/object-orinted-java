package com.roomrental;

@SuppressWarnings("serial")
public class TenantBillNotFoundException extends RuntimeException {

	public TenantBillNotFoundException(String message) {
		super(message);
	}

	
}
