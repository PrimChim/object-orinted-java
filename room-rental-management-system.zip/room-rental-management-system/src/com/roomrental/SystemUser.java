package com.roomrental;

public abstract class SystemUser {
	abstract void TmsUsers();
}
