package com.roomrental;

@SuppressWarnings("serial")
public class LandlordNotFoundException extends RuntimeException{

	public LandlordNotFoundException(String message) {
		super();
	}

	
}
