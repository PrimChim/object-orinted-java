package com.roomrental;

public class TenantBill {

}
