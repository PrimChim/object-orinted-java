package com.roomrental;

public class PropertyDetails {

}
