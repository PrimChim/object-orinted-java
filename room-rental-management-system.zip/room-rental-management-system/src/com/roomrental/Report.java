package com.roomrental;

public class Report {

}
