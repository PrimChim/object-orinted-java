package com.roomrental;

public interface LandlordRights {
	
	void notice();
	
	void reviewBehavior();
	
	void requestAdvance();
}
